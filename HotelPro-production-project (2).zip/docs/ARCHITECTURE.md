# Architecture & data model

```text
React + Vite (client)
  | HTTPS, credentialed requests, CSRF header
  v
Express REST API (server) ---- Razorpay (optional)
  | Mongoose; hotelId tenant scoping; replica-set transaction for new bookings
  v
MongoDB (Atlas for deployments; replica set for transaction support)
```

## Collections

- `Hotel`: tenant, locale/currency configuration
- `User`: staff hotel membership, bcrypt hash, role, active status
- `GuestAccount`: guest-portal identity/password, separate guest session, hotel + guest profile references
- `Room`: property inventory, nightly rate, capacity, housekeeping state, booking lock revision
- `Guest`: property-scoped contact profile
- `Booking`: date range, guest/room references, frozen nightly rate and total, lifecycle and payment states
- `Payment`: provider order/payment references, amount and verified settlement state

## Booking safety

Date intervals use half-open ranges `[checkIn, checkOut)`, so one guest can check out on the same date another checks in. Server code validates capacity and rejects overlapping pending/confirmed/checked-in stays. A transaction also increments the room’s `bookingRevision`, serializing competing reservation writes for that room. This requires a MongoDB replica set. All database filters include the authenticated user's `hotelId`; don't remove this tenant boundary when extending endpoints.

## Trust boundaries

- Browser input is untrusted. Validate and authorize at the API even when the UI already validates.
- Staff and guests use separate HTTP-only session cookies and separately scoped API middleware. A CSRF token is a double-submit cookie/header for mutations. CORS only accepts configured origins.
- Payment secrets and webhook secrets belong only in API secret storage.
- Reports currently provide operational snapshots, not accounting/tax statements.
