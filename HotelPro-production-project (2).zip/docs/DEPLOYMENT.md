# Deployment guide

## Suggested student deployment: Render API + MongoDB Atlas + Vercel UI

Keep MongoDB, API secrets, session signing, and payment keys on the server. The browser should only receive the public API URL and Razorpay public key ID (the backend returns it when creating an order).

### 1) Database — MongoDB Atlas

1. Create a MongoDB Atlas cluster in a region near the API.
2. Create a database user with a long unique password; do not use the Atlas account password.
3. Add the API host’s outbound IP to Network Access. Avoid `0.0.0.0/0` for a public production deployment unless you understand the risk and compensate with strong DB credentials and strict controls.
4. Copy the SRV connection string and replace the password; use database `hotelpro` and ensure the cluster is a replica set (Atlas clusters are).
5. Run backups and test restoration before accepting real guest records.

### 2) API — Render web service

Create a Node web service from the repository, set root directory to `server`, build command `npm install`, start command `npm start`. Add environment variables in the provider dashboard (never commit them):

- `NODE_ENV=production`
- `MONGO_URI=<Atlas SRV URI>`
- `JWT_SECRET=<32+ random characters>`
- `CLIENT_ORIGIN=https://<your-vercel-domain>` (exact origin; comma-separate approved custom domains)
- `ADMIN_EMAIL`, `ADMIN_PASSWORD` (strong, unique), `ADMIN_NAME`, `HOTEL_NAME`, `HOTEL_SLUG`, `HOTEL_CURRENCY`
- Optional Razorpay server secrets and `RAZORPAY_WEBHOOK_SECRET`
- `PORT` is usually provided by the host

Set a persistent stable service URL and HTTPS. After the first deploy, run the one-off seed command `npm run seed` in the API service shell or a one-off job. Restrict the admin password and rotate it after first login. Configure the host health check to `/health`.

### 3) UI — Vercel

Import the `client` folder as the project root. Build command `npm run build`, output directory `dist`. Set `VITE_API_URL=https://<your-api-domain>/api`.

For separate UI/API domains, browser cookies are cross-site: the backend sets `SameSite=None; Secure` in production. Use HTTPS on both services. Set API `CLIENT_ORIGIN` to the exact Vercel/custom UI origin. Set the frontend build variable `VITE_HOTEL_SLUG` to the same hotel slug configured by `HOTEL_SLUG` in the API. If you use sibling subdomains under your own domain, set `COOKIE_DOMAIN=.example.com` on the API; do not set a broad cookie domain for unrelated provider domains. The guest portal is available at `/guest`; guest accounts self-register against the configured property.

### 4) Optional Razorpay

1. Create a Razorpay account and use test credentials first.
2. Add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` only to API environment settings.
3. Set a webhook URL to `https://<api-domain>/api/payments/webhook`, subscribe to `payment.captured` and `payment.failed`, and configure the exact webhook signing secret as `RAZORPAY_WEBHOOK_SECRET`.
4. Validate the full checkout and webhook flow in test mode before switching to live credentials. Never trust a browser success callback alone; this API verifies signatures and accepts signed webhooks.

## Docker Compose

Compose is the easiest reproducible demo environment. It starts a local replica-set MongoDB, Express API and Nginx-served React build. It is not hardened for internet exposure (local Mongo has no authentication). Keep it bound to a private network for demos.

## Production checklist

- [ ] Managed MongoDB with TLS, scoped DB user, backups and tested restore
- [ ] HTTPS, strict CORS allowlist, stable cookie domain, secure secrets, no sample credentials
- [ ] Seeded first admin; remove/disallow any public signup
- [ ] Payment provider in test mode then live mode; signed webhooks monitored
- [ ] Observability: error aggregation, uptime/health alerts, log retention and redaction of PII
- [ ] Automated API tests for roles, tenant isolation, booking overlap/concurrency, cancellations and payment events
- [ ] Privacy notice, retention/deletion policy, local legal requirements and consent for guest contact
- [ ] Rate limits tuned to real usage, dependency scanning, backups and incident response procedure
- [ ] Security review/penetration test before real guest/payment data
