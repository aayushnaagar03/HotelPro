import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { connectDB } from '../src/config/db.js';
import { Hotel } from '../src/models/Hotel.js';
import { User } from '../src/models/User.js';
import { Room } from '../src/models/Room.js';
import { Guest } from '../src/models/Guest.js';
import { Booking } from '../src/models/Booking.js';
await connectDB();
const email=(process.env.ADMIN_EMAIL||'admin@example.com').toLowerCase();
let hotel=await Hotel.findOne({slug:process.env.HOTEL_SLUG||'aster-house'});
if(!hotel)hotel=await Hotel.create({name:process.env.HOTEL_NAME||'The Aster House',slug:process.env.HOTEL_SLUG||'aster-house',currency:process.env.HOTEL_CURRENCY||'INR',address:{city:'New Delhi',country:'India'}});
let admin=await User.findOne({hotelId:hotel._id,email});
if(!admin){if(!process.env.ADMIN_PASSWORD||process.env.ADMIN_PASSWORD.length<12)throw new Error('Set ADMIN_PASSWORD (at least 12 chars) in server/.env before seeding.');admin=await User.create({hotelId:hotel._id,name:process.env.ADMIN_NAME||'Hotel Administrator',email,passwordHash:await bcrypt.hash(process.env.ADMIN_PASSWORD,12),role:'admin'});console.log(`Created admin ${email}`)}else console.log(`Admin already exists: ${email}`);
if(await Room.countDocuments({hotelId:hotel._id})===0){const defs=[['101','Standard Queen',1,2,4200,'occupied'],['102','Standard Twin',1,2,4500,'available'],['103','Deluxe King',1,2,6200,'cleaning'],['201','Deluxe King',2,2,6500,'available'],['202','Executive Suite',2,3,9800,'available'],['203','Garden Suite',2,3,8900,'maintenance'],['301','Standard Queen',3,2,4800,'available'],['302','Penthouse',3,4,18000,'available']];await Room.insertMany(defs.map(([number,type,floor,capacity,price,status])=>({hotelId:hotel._id,number,type,floor,capacity,price,status})));console.log('Created sample rooms')}
if(await Booking.countDocuments({hotelId:hotel._id})===0){
 const rooms=await Room.find({hotelId:hotel._id});const room=id=>rooms.find(r=>r.number===id);const guestA=await Guest.create({hotelId:hotel._id,name:'Olivia Rhye',email:'olivia@example.com',phone:'+91 98765 43210'});const guestB=await Guest.create({hotelId:hotel._id,name:'Phoenix Baker',email:'phoenix@example.com',phone:'+91 98765 43211'});const day=(offset)=>{const d=new Date();d.setUTCHours(0,0,0,0);d.setUTCDate(d.getUTCDate()+offset);return d};
 await Booking.create([{hotelId:hotel._id,code:'HP-DEMO-1001',guestId:guestA._id,roomId:room('101')._id,checkIn:day(-1),checkOut:day(2),guests:2,nightlyRate:room('101').price,totalAmount:room('101').price*3,status:'checked-in',paymentStatus:'pending',createdBy:admin._id,checkedInAt:new Date()},{hotelId:hotel._id,code:'HP-DEMO-1002',guestId:guestB._id,roomId:room('201')._id,checkIn:day(1),checkOut:day(4),guests:2,nightlyRate:room('201').price,totalAmount:room('201').price*3,status:'confirmed',paymentStatus:'pending',createdBy:admin._id}]);console.log('Created sample guest profiles and reservations')}
// For safety, only the initial administrator is bootstrapped. Create other users from Staff & access.
console.log('Seed complete.');await mongoose.disconnect();
