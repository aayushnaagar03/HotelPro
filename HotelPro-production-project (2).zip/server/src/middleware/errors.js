import { HttpError } from '../utils/httpError.js';
export function notFound(_req, _res, next) { next(new HttpError(404, 'The requested resource was not found.')); }
export function errorHandler(err, _req, res, _next) {
  let status = err.status || 500;
  let message = err.message || 'Internal server error.';
  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors).map((e) => e.message).join(', '); }
  if (err.code === 11000) { status = 409; message = 'A record with that value already exists.'; }
  if (err.name === 'CastError') { status = 400; message = 'Invalid identifier.'; }
  if (status >= 500) console.error(err);
  res.status(status).json({ error: message, ...(err.details ? { details: err.details } : {}), ...(process.env.NODE_ENV !== 'production' && status >= 500 ? { stack: err.stack } : {}) });
}
