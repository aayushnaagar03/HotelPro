import crypto from 'node:crypto';
import { HttpError } from '../utils/httpError.js';

const cookieOptions = () => ({ httpOnly: false, secure: process.env.NODE_ENV === 'production', sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax', domain: process.env.COOKIE_DOMAIN || undefined, path: '/', maxAge: 24 * 60 * 60 * 1000 });
export function issueCsrf(req, res) {
  let token = req.cookies?.hotelpro_csrf;
  if (!token) { token = crypto.randomBytes(32).toString('hex'); res.cookie('hotelpro_csrf', token, cookieOptions()); }
  res.json({ csrfToken: token });
}
export function requireCsrf(req, _res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const cookie = req.cookies?.hotelpro_csrf;
  const header = req.get('x-csrf-token');
  if (!cookie || !header || cookie.length !== header.length || !crypto.timingSafeEqual(Buffer.from(cookie), Buffer.from(header))) return next(new HttpError(403, 'Security token missing or invalid. Refresh the page and try again.'));
  next();
}
