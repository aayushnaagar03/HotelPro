import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';
import { HttpError } from '../utils/httpError.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const requireAuth = asyncHandler(async (req, _res, next) => {
  const token = req.cookies?.hotelpro_session;
  if (!token) throw new HttpError(401, 'Please sign in to continue.');
  let payload;
  try { payload = jwt.verify(token, process.env.JWT_SECRET); }
  catch { throw new HttpError(401, 'Your session has expired. Please sign in again.'); }
  const user = await User.findById(payload.sub).select('-passwordHash +tokenVersion');
  if (!user || !user.active) throw new HttpError(401, 'This account is inactive.');
  if ((payload.ver || 0) !== (user.tokenVersion || 0)) throw new HttpError(401, 'Your session is no longer valid. Please sign in again.');
  req.user = user;
  next();
});

export const allowRoles = (...roles) => (req, _res, next) => {
  if (!req.user || !roles.includes(req.user.role)) return next(new HttpError(403, 'You do not have permission to do that.'));
  next();
};

export function issueSession(res, user) {
  const token = jwt.sign({ sub: user.id, hotelId: user.hotelId, role: user.role, ver: user.tokenVersion || 0 }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });
  const production = process.env.NODE_ENV === 'production';
  res.cookie('hotelpro_session', token, { httpOnly: true, secure: production, sameSite: production ? 'none' : 'lax', domain: process.env.COOKIE_DOMAIN || undefined, maxAge: 24 * 60 * 60 * 1000, path: '/' });
}
export function clearSession(res) {
  const production = process.env.NODE_ENV === 'production';
  res.clearCookie('hotelpro_session', { httpOnly: true, secure: production, sameSite: production ? 'none' : 'lax', domain: process.env.COOKIE_DOMAIN || undefined, path: '/' });
}
