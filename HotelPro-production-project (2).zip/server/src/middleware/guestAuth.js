import jwt from 'jsonwebtoken';
import { GuestAccount } from '../models/GuestAccount.js';
import { HttpError } from '../utils/httpError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
const options = () => { const production=process.env.NODE_ENV==='production'; return { httpOnly:true,secure:production,sameSite:production?'none':'lax',domain:process.env.COOKIE_DOMAIN||undefined,maxAge:24*60*60*1000,path:'/' }; };
export const requireGuestAuth=asyncHandler(async(req,_res,next)=>{
  const token=req.cookies?.hotelpro_guest_session;
  if(!token)throw new HttpError(401,'Please sign in to your guest account.');
  let payload;try{payload=jwt.verify(token,process.env.JWT_SECRET)}catch{throw new HttpError(401,'Your guest session has expired. Please sign in again.')}
  const account=await GuestAccount.findById(payload.sub).select('-passwordHash +tokenVersion');
  if(!account||!account.active)throw new HttpError(401,'This guest account is inactive.');
  if((payload.ver||0)!==(account.tokenVersion||0))throw new HttpError(401,'Your guest session is no longer valid.');
  req.guestAccount=account;req.hotelId=account.hotelId;req.guestId=account.guestId;next();
});
export function issueGuestSession(res,account){const token=jwt.sign({sub:account.id,hotelId:account.hotelId,guestId:account.guestId,ver:account.tokenVersion||0,kind:'guest'},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||'1d'});res.cookie('hotelpro_guest_session',token,options())}
export function clearGuestSession(res){const {httpOnly,secure,sameSite,domain,path}=options();res.clearCookie('hotelpro_guest_session',{httpOnly,secure,sameSite,domain,path})}
