export const bookingTransitions = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['checked-in', 'cancelled'],
  'checked-in': ['completed'],
  completed: [],
  cancelled: []
};

export function canTransition(from, to) {
  return from === to || Boolean(bookingTransitions[from]?.includes(to));
}

// Booking intervals are half-open: check-in is included, check-out is excluded.
export function datesOverlap(startA, endA, startB, endB) {
  return new Date(startA) < new Date(endB) && new Date(endA) > new Date(startB);
}
