import { Router } from 'express';
import { Booking } from '../models/Booking.js';
import { Room } from '../models/Room.js';
import { Guest } from '../models/Guest.js';
import { asyncHandler } from '../utils/asyncHandler.js';
const router=Router();
router.get('/',asyncHandler(async(req,res)=>{const hotelId=req.user.hotelId;const now=new Date();now.setHours(0,0,0,0);const tomorrow=new Date(now);tomorrow.setDate(tomorrow.getDate()+1);const monthStart=new Date(now.getFullYear(),now.getMonth(),1);const [rooms,totalBookings,arrivals,departures,guests,activeBookings,recent,paid]=await Promise.all([
Room.find({hotelId,active:true}).select('status'),Booking.countDocuments({hotelId}),Booking.countDocuments({hotelId,checkIn:{$gte:now,$lt:tomorrow},status:{$in:['confirmed','pending']}}),Booking.countDocuments({hotelId,checkOut:{$gte:now,$lt:tomorrow},status:'checked-in'}),Guest.countDocuments({hotelId}),Booking.countDocuments({hotelId,status:{$in:['pending','confirmed','checked-in']}}),Booking.find({hotelId}).populate('guestId','name').populate('roomId','number type').sort({createdAt:-1}).limit(8),Booking.aggregate([{$match:{hotelId,paymentStatus:'paid',createdAt:{$gte:monthStart}}},{$group:{_id:null,revenue:{$sum:'$totalAmount'}}}])]);
const counts=rooms.reduce((a,r)=>(a[r.status]=(a[r.status]||0)+1,a),{});res.json({metrics:{occupancyPercent:rooms.length?Math.round((counts.occupied||0)/rooms.length*100):0,roomCount:rooms.length,activeBookings,totalBookings,arrivals,departures,guestCount:guests,monthRevenue:paid[0]?.revenue||0,roomStatuses:counts},recentBookings:recent});}));
export default router;
