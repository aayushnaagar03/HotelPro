import { Router } from 'express';
import { Guest } from '../models/Guest.js';
import { Booking } from '../models/Booking.js';
import { asyncHandler } from '../utils/asyncHandler.js';
const router=Router();
router.get('/',asyncHandler(async(req,res)=>{const filter={hotelId:req.user.hotelId};if(req.query.q){const rx=new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i');filter.$or=[{name:rx},{email:rx},{phone:rx}]}const guests=await Guest.find(filter).sort({updatedAt:-1}).limit(200);const ids=guests.map(g=>g._id);const counts=await Booking.aggregate([{$match:{hotelId:guests[0]?.hotelId||req.user.hotelId,guestId:{$in:ids},status:{$ne:'cancelled'}}},{$group:{_id:'$guestId',count:{$sum:1}}}]);const map=new Map(counts.map(c=>[String(c._id),c.count]));res.json({guests:guests.map(g=>({...g.toJSON(),reservationCount:map.get(String(g._id))||0}))})}));
export default router;
