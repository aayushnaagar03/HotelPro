import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { rateLimit } from 'express-rate-limit';
import { body, validationResult } from 'express-validator';
import { GuestAccount } from '../models/GuestAccount.js';
import { Guest } from '../models/Guest.js';
import { Hotel } from '../models/Hotel.js';
import { requireGuestAuth,issueGuestSession,clearGuestSession } from '../middleware/guestAuth.js';
import { HttpError } from '../utils/httpError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
const router=Router();
const limit=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false});
const validate=(req,_res,next)=>{const e=validationResult(req);if(!e.isEmpty())return next(new HttpError(400,e.array()[0].msg));next()};
const hotelFor=async(slug)=>{const hotel=await Hotel.findOne({slug:slug||process.env.HOTEL_SLUG||'aster-house',active:true});if(!hotel)throw new HttpError(404,'Hotel not found.');return hotel};
router.post('/register',limit,body('name').trim().notEmpty().withMessage('Your name is required.'),body('email').isEmail().withMessage('Enter a valid email.'),body('password').isLength({min:12}).withMessage('Password must be at least 12 characters.'),body('phone').optional({values:'falsy'}).isLength({max:30}),validate,asyncHandler(async(req,res)=>{
  const hotel=await hotelFor(req.body.hotelSlug);const email=req.body.email.toLowerCase().trim();if(await GuestAccount.exists({hotelId:hotel._id,email}))throw new HttpError(409,'An account already exists for this email. Sign in instead.');
  let guest=await Guest.findOne({hotelId:hotel._id,email});if(guest){guest.name=req.body.name.trim();if(req.body.phone)guest.phone=req.body.phone;await guest.save()}else guest=await Guest.create({hotelId:hotel._id,name:req.body.name.trim(),email,phone:req.body.phone});
  const account=await GuestAccount.create({hotelId:hotel._id,guestId:guest._id,email,passwordHash:await bcrypt.hash(req.body.password,12)});issueGuestSession(res,account);res.status(201).json({guest:guest.toJSON(),hotel:{name:hotel.name,slug:hotel.slug,currency:hotel.currency}});
}));
router.post('/login',limit,body('email').isEmail().withMessage('Enter a valid email.'),body('password').notEmpty().withMessage('Password is required.'),validate,asyncHandler(async(req,res)=>{
  const hotel=await hotelFor(req.body.hotelSlug);const account=await GuestAccount.findOne({hotelId:hotel._id,email:req.body.email.toLowerCase().trim()}).select('+passwordHash +tokenVersion');if(!account||!account.active||!(await account.comparePassword(req.body.password)))throw new HttpError(401,'Email or password is incorrect.');account.lastLoginAt=new Date();await account.save();issueGuestSession(res,account);const guest=await Guest.findById(account.guestId);res.json({guest,hotel:{name:hotel.name,slug:hotel.slug,currency:hotel.currency}});
}));
router.post('/logout',(_req,res)=>{clearGuestSession(res);res.status(204).end()});
router.get('/me',requireGuestAuth,asyncHandler(async(req,res)=>{const [guest,hotel]=await Promise.all([Guest.findOne({_id:req.guestId,hotelId:req.hotelId}),Hotel.findById(req.hotelId).select('name slug currency')]);res.json({guest,hotel})}));
router.post('/change-password',requireGuestAuth,body('currentPassword').notEmpty(),body('newPassword').isLength({min:12}),validate,asyncHandler(async(req,res)=>{const a=await GuestAccount.findById(req.guestAccount._id).select('+passwordHash +tokenVersion');if(!a||!(await a.comparePassword(req.body.currentPassword)))throw new HttpError(400,'Current password is incorrect.');a.passwordHash=await bcrypt.hash(req.body.newPassword,12);a.tokenVersion=(a.tokenVersion||0)+1;await a.save();clearGuestSession(res);res.status(204).end()}));
export default router;
