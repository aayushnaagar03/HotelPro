import { Router } from 'express';
import crypto from 'node:crypto';
import mongoose from 'mongoose';
import { body, query, validationResult } from 'express-validator';
import { Booking } from '../models/Booking.js';
import { Guest } from '../models/Guest.js';
import { Room } from '../models/Room.js';
import { Hotel } from '../models/Hotel.js';
import { allowRoles } from '../middleware/auth.js';
import { HttpError } from '../utils/httpError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { canTransition } from '../utils/bookingRules.js';
const router=Router();
const validate=(req,_res,next)=>{const e=validationResult(req);if(!e.isEmpty())return next(new HttpError(400,e.array()[0].msg));next()};
function dateStart(value){const d=new Date(value);if(Number.isNaN(d.getTime()))throw new HttpError(400,'Invalid booking date.');d.setUTCHours(0,0,0,0);return d}
function dateEnd(value){const d=new Date(value);if(Number.isNaN(d.getTime()))throw new HttpError(400,'Invalid booking date.');d.setUTCHours(0,0,0,0);return d}
router.get('/',query('page').optional().isInt({min:1}),query('limit').optional().isInt({min:1,max:100}),validate,asyncHandler(async(req,res)=>{
 const page=Number(req.query.page||1),limit=Number(req.query.limit||20),filter={hotelId:req.user.hotelId};if(req.query.status)filter.status=req.query.status;if(req.query.from||req.query.to){filter.checkIn={};if(req.query.from)filter.checkIn.$gte=dateStart(req.query.from);if(req.query.to)filter.checkIn.$lte=dateEnd(req.query.to)}
 if(req.query.q){const rx=new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i');const guests=await Guest.find({hotelId:req.user.hotelId,$or:[{name:rx},{email:rx}]}).select('_id');filter.$or=[{code:rx},{guestId:{$in:guests.map(g=>g._id)}}]}
 const [items,total]=await Promise.all([Booking.find(filter).populate('guestId','name email phone').populate('roomId','number type').sort({createdAt:-1}).skip((page-1)*limit).limit(limit),Booking.countDocuments(filter)]);res.json({bookings:items,total,page,pages:Math.ceil(total/limit)});
}));
router.post('/',allowRoles('admin','manager','receptionist'),body('guest.name').trim().notEmpty().withMessage('Guest name is required.'),body('guest.email').optional({values:'falsy'}).isEmail().withMessage('Guest email is invalid.'),body('roomId').isMongoId().withMessage('Choose a valid room.'),body('checkIn').isISO8601().withMessage('Check-in date is required.'),body('checkOut').isISO8601().withMessage('Check-out date is required.'),body('guests').optional().isInt({min:1,max:20}),validate,asyncHandler(async(req,res)=>{
 const {guest:guestInput,roomId,guests=1,specialRequests}=req.body;const start=dateStart(req.body.checkIn),end=dateEnd(req.body.checkOut);const today=new Date();today.setUTCHours(0,0,0,0);if(start<today)throw new HttpError(400,'Check-in cannot be in the past.');if(end<=start)throw new HttpError(400,'Check-out must be after check-in.');
 const session=await mongoose.startSession();let booking;
 try { await session.withTransaction(async()=>{
   const room=await Room.findOne({_id:roomId,hotelId:req.user.hotelId,active:true}).session(session);if(!room)throw new HttpError(404,'Room not found.');if(room.status==='maintenance')throw new HttpError(409,'This room is under maintenance.');if(Number(guests)>room.capacity)throw new HttpError(400,`This room accommodates up to ${room.capacity} guests.`);
   const conflict=await Booking.findOne({hotelId:req.user.hotelId,roomId:room._id,status:{$in:['pending','confirmed','checked-in']},checkIn:{$lt:end},checkOut:{$gt:start}}).session(session);if(conflict)throw new HttpError(409,'The room is already booked for some or all of those dates.');
   // This write serializes concurrent reservation attempts for the same room. MongoDB transactions
   // require Atlas or a replica-set deployment; see the deployment guide.
   await Room.updateOne({_id:room._id,hotelId:req.user.hotelId},{$inc:{bookingRevision:1}},{session});
   let guest;if(guestInput.email)guest=await Guest.findOne({hotelId:req.user.hotelId,email:guestInput.email.toLowerCase().trim()}).session(session);if(guest){guest.name=guestInput.name.trim();if(guestInput.phone)guest.phone=guestInput.phone;await guest.save({session})}else [guest]=await Guest.create([{hotelId:req.user.hotelId,name:guestInput.name,email:guestInput.email,phone:guestInput.phone}],{session});
   const nights=Math.round((end-start)/86400000);const code=`HP-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
   [booking]=await Booking.create([{hotelId:req.user.hotelId,code,guestId:guest._id,roomId:room._id,checkIn:start,checkOut:end,guests:Number(guests),nightlyRate:room.price,totalAmount:room.price*nights,specialRequests,createdBy:req.user._id,status:'confirmed'}],{session});
 }); } finally { await session.endSession(); }
 await booking.populate([{path:'guestId',select:'name email phone'},{path:'roomId',select:'number type'}]);res.status(201).json({booking});
}));
router.patch('/:id/status',allowRoles('admin','manager','receptionist'),body('status').isIn(['pending','confirmed','checked-in','completed','cancelled']).withMessage('Invalid booking status.'),validate,asyncHandler(async(req,res)=>{
 const booking=await Booking.findOne({_id:req.params.id,hotelId:req.user.hotelId});if(!booking)throw new HttpError(404,'Reservation not found.');const next=req.body.status;if(booking.status===next){await booking.populate([{path:'guestId',select:'name email phone'},{path:'roomId',select:'number type'}]);return res.json({booking})}if(!canTransition(booking.status,next))throw new HttpError(409,`Cannot change a ${booking.status} reservation to ${next}.`);
 if(next==='checked-in'){if(new Date(booking.checkIn)>new Date(new Date().setHours(23,59,59,999)))throw new HttpError(409,'Guest cannot check in before the arrival date.');await Room.updateOne({_id:booking.roomId,hotelId:req.user.hotelId},{$set:{status:'occupied'}});booking.checkedInAt=new Date()}
 if(next==='completed'){await Room.updateOne({_id:booking.roomId,hotelId:req.user.hotelId},{$set:{status:'cleaning'}});booking.checkedOutAt=new Date();await Guest.updateOne({_id:booking.guestId,hotelId:req.user.hotelId},{$inc:{totalStays:1}})}
 if(next==='cancelled'){booking.cancelledAt=new Date();if(booking.status==='checked-in')throw new HttpError(409,'A checked-in reservation cannot be cancelled; complete the stay instead.')}
 booking.status=next;await booking.save();await booking.populate([{path:'guestId',select:'name email phone'},{path:'roomId',select:'number type'}]);res.json({booking});
}));
router.get('/:id',asyncHandler(async(req,res)=>{const booking=await Booking.findOne({_id:req.params.id,hotelId:req.user.hotelId}).populate('guestId').populate('roomId');if(!booking)throw new HttpError(404,'Reservation not found.');res.json({booking})}));
export default router;
