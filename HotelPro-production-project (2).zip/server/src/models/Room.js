import mongoose from 'mongoose';
const roomSchema = new mongoose.Schema({
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true }, number: { type: String, required: true, trim: true }, type: { type: String, required: true, trim: true }, floor: { type: Number, default: 1, min: 0 }, capacity: { type: Number, default: 2, min: 1, max: 20 }, price: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['available', 'occupied', 'cleaning', 'maintenance'], default: 'available', index: true }, amenities: [{ type: String, trim: true }], description: { type: String, maxlength: 1000 }, active: { type: Boolean, default: true }, bookingRevision: { type: Number, default: 0 }
}, { timestamps: true });
roomSchema.index({ hotelId: 1, number: 1 }, { unique: true });
export const Room = mongoose.model('Room', roomSchema);
