import mongoose from 'mongoose';
const hotelSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 }, slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  address: { street: String, city: String, region: String, country: String, postalCode: String }, currency: { type: String, default: 'INR', uppercase: true, minlength: 3, maxlength: 3 }, timezone: { type: String, default: 'Asia/Kolkata' }, active: { type: Boolean, default: true }
}, { timestamps: true });
export const Hotel = mongoose.model('Hotel', hotelSchema);
