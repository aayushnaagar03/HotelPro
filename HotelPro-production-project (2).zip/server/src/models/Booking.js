import mongoose from 'mongoose';
const bookingSchema = new mongoose.Schema({
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true }, code: { type: String, required: true }, guestId: { type: mongoose.Schema.Types.ObjectId, ref: 'Guest', required: true, index: true }, roomId: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true, index: true },
  checkIn: { type: Date, required: true, index: true }, checkOut: { type: Date, required: true, index: true }, guests: { type: Number, min: 1, max: 20, default: 1 }, nightlyRate: { type: Number, required: true, min: 0 }, totalAmount: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['pending', 'confirmed', 'checked-in', 'completed', 'cancelled'], default: 'confirmed', index: true }, paymentStatus: { type: String, enum: ['pending', 'paid', 'partially-refunded', 'refunded', 'failed'], default: 'pending' }, specialRequests: { type: String, maxlength: 1000 }, createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, checkedInAt: Date, checkedOutAt: Date, cancelledAt: Date
}, { timestamps: true });
bookingSchema.index({ hotelId: 1, code: 1 }, { unique: true });
bookingSchema.index({ hotelId: 1, roomId: 1, checkIn: 1, checkOut: 1, status: 1 });
export const Booking = mongoose.model('Booking', bookingSchema);
