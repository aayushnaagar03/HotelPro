import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
const schema = new mongoose.Schema({
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true },
  guestId: { type: mongoose.Schema.Types.ObjectId, ref: 'Guest', required: true, index: true },
  email: { type: String, required: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  active: { type: Boolean, default: true },
  tokenVersion: { type: Number, default: 0, select: false },
  lastLoginAt: Date
}, { timestamps: true });
schema.index({ hotelId: 1, email: 1 }, { unique: true });
schema.methods.comparePassword = function (password) { return bcrypt.compare(password, this.passwordHash); };
schema.set('toJSON', { transform(_doc, ret) { delete ret.passwordHash; delete ret.tokenVersion; delete ret.__v; return ret; } });
export const GuestAccount = mongoose.model('GuestAccount', schema);
