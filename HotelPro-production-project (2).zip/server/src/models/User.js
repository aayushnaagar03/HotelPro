import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
const userSchema = new mongoose.Schema({
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true }, name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, lowercase: true, trim: true }, passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ['admin', 'manager', 'receptionist', 'housekeeping'], default: 'receptionist', index: true }, active: { type: Boolean, default: true }, tokenVersion: { type: Number, default: 0, select: false }, lastLoginAt: Date
}, { timestamps: true });
userSchema.index({ email: 1 }, { unique: true });
userSchema.methods.comparePassword = function (password) { return bcrypt.compare(password, this.passwordHash); };
userSchema.set('toJSON', { transform(_doc, ret) { delete ret.passwordHash; delete ret.tokenVersion; delete ret.__v; return ret; } });
export const User = mongoose.model('User', userSchema);
