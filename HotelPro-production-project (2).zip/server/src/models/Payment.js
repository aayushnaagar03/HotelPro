import mongoose from 'mongoose';
const paymentSchema = new mongoose.Schema({
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true }, bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, index: true },
  provider: { type: String, enum: ['razorpay'], required: true }, providerOrderId: { type: String, unique: true, sparse: true }, providerPaymentId: { type: String, unique: true, sparse: true }, amount: { type: Number, required: true, min: 1 }, currency: { type: String, required: true }, status: { type: String, enum: ['created', 'paid', 'failed', 'refunded'], default: 'created' }, capturedAt: Date
}, { timestamps: true });
export const Payment = mongoose.model('Payment', paymentSchema);
