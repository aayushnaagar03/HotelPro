import mongoose from 'mongoose';
const guestSchema = new mongoose.Schema({ hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true, index: true }, name: { type: String, required: true, trim: true, maxlength: 120 }, email: { type: String, lowercase: true, trim: true, index: true }, phone: { type: String, trim: true, maxlength: 30 }, notes: { type: String, maxlength: 1000 }, totalStays: { type: Number, default: 0 } }, { timestamps: true });
guestSchema.index({ hotelId: 1, email: 1 });
export const Guest = mongoose.model('Guest', guestSchema);
