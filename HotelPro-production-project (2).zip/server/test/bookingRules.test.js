import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransition, datesOverlap } from '../src/utils/bookingRules.js';

test('stay ranges allow same-day checkout/check-in', () => {
  assert.equal(datesOverlap('2026-07-10','2026-07-12','2026-07-12','2026-07-14'), false);
});

test('stay ranges reject intersecting nights', () => {
  assert.equal(datesOverlap('2026-07-10','2026-07-13','2026-07-12','2026-07-14'), true);
  assert.equal(datesOverlap('2026-07-12','2026-07-14','2026-07-10','2026-07-13'), true);
});

test('reservation lifecycle allows only defined transitions', () => {
  assert.equal(canTransition('confirmed','checked-in'), true);
  assert.equal(canTransition('checked-in','completed'), true);
  assert.equal(canTransition('completed','cancelled'), false);
  assert.equal(canTransition('cancelled','confirmed'), false);
  assert.equal(canTransition('confirmed','confirmed'), true);
});
