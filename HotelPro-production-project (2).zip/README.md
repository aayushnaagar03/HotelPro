# HotelPro — Hotel Management System (MERN)

A full-stack, multi-tenant hotel operations project built with **MongoDB, Express, React, and Node.js**. It is designed as a deployable college project and a production-oriented foundation, with a clear separation between API and UI.

## What is included

- Separate guest and staff portals: guest registration/sign-in, private reservation dashboard, availability search, self-booking and eligible unpaid cancellation; staff/admin sign-in with bcrypt password hashing, separate HTTP-only session cookies, CSRF double-submit protection, CORS allowlist, rate limiting, and role-based access
- Property-scoped data access for each staff account
- Hotel dashboard metrics, room inventory, occupancy/housekeeping statuses, reservation search and status transitions, guest directory, staff access page, CSV reporting
- Reservation creation with guest profile reuse, dates/rate snapshot, capacity checks, and overlapping-stay detection
- MongoDB transaction + per-room write serialization to avoid concurrent double-booking (requires a replica set; Atlas and the included Compose stack support this)
- Optional Razorpay order, signature verification, and webhook endpoints; payment keys are server-only
- Input validation, Mongo query sanitization, helmet security headers, compressed responses, structured API error handling, graceful shutdown, Dockerfiles, Compose, CI workflow, OpenAPI reference, deployment/runbook docs

## Quick start (recommended: Docker Compose)

Requirements: Docker Desktop / Docker Engine with Compose.

1. Copy the environment template and set strong, unique credentials:

   ```bash
   cp .env.example .env
   ```

   Change `JWT_SECRET` to a random string of at least 32 characters and set a unique `ADMIN_PASSWORD` (12+ characters). Do not commit `.env`.

2. Start the app:

   ```bash
   docker compose up --build -d
   ```

3. Create the first administrator and initial demo room inventory:

   ```bash
   docker compose exec api npm run seed
   ```

4. Open **http://localhost:8080**, and sign in with `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env`.

The Compose stack uses a local MongoDB replica set so reservation transactions work. It is for local development/college demos; do not expose this unauthenticated local database stack directly to the public internet. For a public launch, use MongoDB Atlas, managed hosting, TLS, managed secrets, backups, and a security review.

## Development without Docker

Use a MongoDB Atlas development cluster (or another replica-set URI). Transactional booking creation needs a replica set; a standalone local MongoDB server is not sufficient.

```bash
cp server/.env.example server/.env
# Edit server/.env: set MONGO_URI to your Atlas connection string,
# JWT_SECRET (32+ random characters), ADMIN_PASSWORD, and CLIENT_ORIGIN.

npm install
npm --prefix server install
npm --prefix client install
npm run seed
npm run dev
```

Staff/admin UI: http://localhost:5173 · Guest portal: http://localhost:5173/guest · API: http://localhost:5000 · Health check: http://localhost:5000/health

## First administrator / seed behaviour

`npm run seed` creates the configured hotel, its first admin, starter rooms, and two sample guest reservations if they do not already exist. It does not reset or overwrite existing data. In Docker Compose run it as shown above. For hosted deployments, run the seed command once as a one-off job after the database is connected. Staff accounts are created by an admin/manager in **Staff & access**; share temporary passwords securely and rotate them.

## Roles

- **admin** — all property operations and staff access
- **manager** — room, booking, reporting, and staff management
- **receptionist** — guest reservations and front-desk operations
- **housekeeping** — limited room status / stay operations

Every authenticated query is scoped to the current user’s `hotelId`. Public self-registration is intentionally disabled; the first admin is provisioned through the seed command.

## Environment variables

See [`server/.env.example`](server/.env.example) and [deployment guide](docs/DEPLOYMENT.md). Important settings:

- `MONGO_URI` — MongoDB replica-set connection string
- `JWT_SECRET` — long random server secret; never expose to Vite/browser
- `CLIENT_ORIGIN` — exact allowed browser origin(s), comma-separated
- `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `HOTEL_NAME`, `HOTEL_SLUG` — first seed values
- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` — optional payment configuration
- `COOKIE_DOMAIN` — optional shared cookie domain when the API and UI use sibling subdomains

## API overview

The full OpenAPI 3.1 document is in [`docs/openapi.yaml`](docs/openapi.yaml). Core endpoints:

- `GET /health`
- `GET /api/auth/csrf`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `POST /api/guest-auth/register`, `POST /api/guest-auth/login`, `POST /api/guest-auth/logout`, `GET /api/guest-auth/me`
- `GET /api/guest-portal/dashboard`, `GET /api/guest-portal/rooms`, `POST /api/guest-portal/bookings`, `PATCH /api/guest-portal/bookings/:id/cancel`
- `GET/POST /api/rooms`, `PATCH/DELETE /api/rooms/:id`
- `GET/POST /api/bookings`, `GET /api/bookings/:id`, `PATCH /api/bookings/:id/status`
- `GET /api/guests`, `GET/POST/PATCH /api/staff`
- `GET /api/dashboard`
- `POST /api/payments/order/:bookingId`, `POST /api/payments/verify`, `POST /api/payments/webhook`

All write requests require an `X-CSRF-Token` matching the `hotelpro_csrf` cookie. The UI handles this automatically. Login uses the HTTP-only `hotelpro_session` cookie.

## Tests / code checks

- Backend unit tests: `npm --prefix server test` (booking date ranges and lifecycle transitions).
- Frontend production build: `npm --prefix client run build`.
- Dependency checks used during preparation: `npm audit` (client and server production dependencies).
- CI configuration: `.github/workflows/ci.yml`.

Before a real business launch, add automated integration tests against a disposable replica set, email delivery and password reset, audit-log retention, backup/restore drills, monitoring/alerting, privacy/legal review, and a penetration test. Configure payment webhooks and verify settlement independently. This project is a college-ready deployable codebase, not a claim of third-party security certification or a substitute for a production security audit.
